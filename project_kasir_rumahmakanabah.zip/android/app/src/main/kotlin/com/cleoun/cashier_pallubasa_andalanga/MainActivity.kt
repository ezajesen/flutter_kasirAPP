package com.cleoun.cashier_pallubasa_andalanga

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
