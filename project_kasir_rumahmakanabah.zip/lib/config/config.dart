import 'package:flutter/material.dart';

part 'size_config.dart';
