part of 'theme.dart';

class ColorCollections {
  static const Color pallubasa = Color(0xFFFFDBAA);
  static const Color nasi = Color(0xFFADD8FF);
  static const Color bungkus = Color(0xFFADBFFF);
  static const Color telur = Color(0xFFD2DCEF);
  static const Color airMineral = Color(0xFF8EFDBD);
  static const Color perkedel = Color(0xFF85B1CF);
  static const Color tehBotol = Color(0xFFB1BEFF);
  static const Color kacang = Color(0xFFFFDBAA);
}
